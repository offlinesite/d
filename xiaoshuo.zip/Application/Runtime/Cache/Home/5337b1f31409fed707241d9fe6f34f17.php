<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<title><?php echo ($TDK["title"]); ?></title>
	<meta name="keywords" content="<?php echo ($TDK["keyword"]); ?>" />
	<meta name="description" content="<?php echo ($TDK["description"]); ?>" />
	<link rel="canonical" href="<?php echo ($TDK["weburl"]); ?>"/>
	<meta name="applicable-device" content="pc">
	<meta http-equiv="mobile-agent" content="format=html5; url=<?php echo ($TDK["canonicalurl_m"]); ?>">
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/style.css?v<?php echo ($version); ?>" />
	<script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/header.js?v<?php echo ($version); ?>"></script>
	<script>var znsid = '<?php echo ($comset["znsid"]); ?>';</script>
	<!-- 以下为轮播js和css -->
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/c/zzsc.css" />
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/paihuang.js"> </script>
</head>
<body>
<div id="wrapper">
	<div class="header">
	<div class="header_logo">
		<a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>"><?php echo ($TDK["webname"]); ?></a>
	</div>
			<div class="inner s96 cf">
				<form action="<?php echo U('/home/search');?>" method="post">
				<input type="hidden" name="action" value="search">
				<input name="q" placeholder="可以搜索 作者 书名" type="text" class="searchinput" required><button class="searchbtn" type="submit">搜索</button>
				</form>
			</div>
			<div class="inner s97 cf">
			<div class="daos1">
				<a href="<?php echo ($catelist["all"]); ?>">全部分类</a>
				<a href="<?php echo U('/quanben');?>">完结小说</a>
				<a href="<?php echo ($TDK["canonicalurl_m"]); ?>">手机版</a>
			</div>
			</div>
</div>
<div class="s92">
<div class="nav">
	<ul>
		<li><a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>">书城首页</a></li>
				<?php if(is_array($category)): foreach($category as $key=>$vo): ?><li class="tou2" ><a href="<?php echo ($vo['url']); ?>"><?php echo ($vo['name']); ?></a></li><?php endforeach; endif; ?>
		<li><a href="<?php echo ($catelist["top"]); ?>">排行榜单</a></li>
		<li><a href="<?php echo U('/home/index/bookcase');?>">书架</a></li>
	</ul>
</div>
</div>
	<div id="main">
<!-- 新版块01开始 -->
	<div class="focus-wrap inner-wrap mb20 cf">
				<div class="week-rec-wrap">
					<b></b>
					<h3 class="lang">本周强推</h3>
					<div class="rec-list">
						<ul>
					<?php if(is_array($dataarea_list["pc_index_tuinile"])): foreach($dataarea_list["pc_index_tuinile"] as $key=>$v): ?><li>
			<em><a class="name" href="<?php echo ($v["rewriteurl"]); ?>" target="_blank" title="《<?php echo ($v["title"]); ?>》"><?php echo ($v["title"]); ?></a></em>
				</li><?php endforeach; endif; ?>
						</ul>
					</div>
				</div>
<!-- 新版块01结束 -->

<!-- 新版块02开始 -->
	<div class="channel-focus big-mode fl">
<!-- 新版块02a开始 -->
	  <div class="big-list">
		<ul class="cf">
		<?php if(is_array($dataarea_list["pc_index_tuinilea"])): foreach($dataarea_list["pc_index_tuinilea"] as $key=>$v): ?><li>
		<div class="book-shadow"></div>
			<div class="img-box">
					<a href="<?php echo ($v["rewriteurl"]); ?>" target="_blank"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>" width="72" height="96" onerror="this.src='/Public/images/nocover.jpg'" /></a>
				</div>
		<h3><a href="<?php echo ($v["rewriteurl"]); ?>"  target="_blank"><?php echo ($v["title"]); ?></a></h3>
		<p><?php echo ($v["author"]); ?></p>
		</li><?php endforeach; endif; ?>
        </ul>
       </div>
	
<!-- 新版块02a结束 -->
<!-- 新板块02b开始 -->
<div class="new-wrap cf">
        <h3></h3>
        <ul class="cf">
		<?php if(is_array($dataarea_list["pc_index_tuinileb"])): foreach($dataarea_list["pc_index_tuinileb"] as $key=>$v): ?><li>
                <h4><a href="<?php echo ($v["rewriteurl"]); ?>" target="_blank"><?php echo ($v["title"]); ?></a></h4>
                <p><?php echo ($v["author"]); ?></p>
                </li><?php endforeach; endif; ?>
        </ul>
    </div>
<!-- 新板块02b结束 -->
 </div>
</div>
<!-- 新板块02结束 -->
<?php echo ($advcode["index_1"]["code"]); ?>
<!-- 老版块a开始 -->
		<div id="hotcontent">
		<!-- 老a版块第一部分开始 -->
			<div class="l">
			<h3 class="lang">给你推荐<em class="icon icon-edit_rec"></em></h3>
				<?php if(is_array($dataarea_list["pc_index_fengtui"])): foreach($dataarea_list["pc_index_fengtui"] as $key=>$v): ?><div class="item">
					<div class="image">
						<a href="<?php echo ($v["rewriteurl"]); ?>" title="《<?php echo ($v["title"]); ?>》在线阅读"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>" width="72" height="96" onerror="this.src='/Public/images/nocover.jpg'" /></a>
					</div>
					<dl>
						<dt>
						    <a href="<?php echo ($v["rewriteurl"]); ?>"><?php echo ($v["title"]); ?></a>
						</dt>
						<dd>
						
						<?php echo ($v["description"]); ?>...
						</dd>
						<div class="state-box cf">
						<i><?php echo ($v["catename"]); ?></i>
						<a class="author default"><img src="/Public/<?php echo ($theme); ?>/images/zuozhei.png"/><?php echo ($v["author"]); ?></a></div>
					</dl>
					<div class="clear"></div>
				</div><?php endforeach; endif; ?>
			</div>
		<!-- 老a版块第一部分结束 -->
		<!-- 老a版块第二部分开始 -->
			<div class="r">
			<h3 class="lang">好书榜<em class="icon icon-fsg"></em></h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_jingdian"])): foreach($dataarea_list["pc_index_jingdian"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<div class="s-index-star s-index-star-<?php echo ($k); ?>"><div class="s-index-star-big wrap"><span class="one">&nbsp;</span><span class="two">&nbsp;</span><span class="three">&nbsp;</span><span class="four">&nbsp;</span><span class="five">&nbsp;</span></div></div>
<a href="<?php echo ($v["rewriteurl"]); ?>"   class="event-exe-install s-index-down s-index-icon">阅&nbsp;读</a>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>
			<!-- 老a版块第二部分结束 -->
			<div class="clear"></div>
		</div>
<!-- 老版本a结束 -->
<?php echo ($advcode["index_2"]["code"]); ?>
<!-- 最新更新开始 -->
		<div id="newscontent">
			<div class="l">
				<h2>
					最近更新列表
				</h2>
				<ul>
					<?php if(is_array($updatelist)): foreach($updatelist as $key=>$v): ?><li>
						<span class="s1">[<?php echo ($v['catename']); ?>]</span>
						<span class="s2"><a href="<?php echo ($v['rewriteurl']); ?>" title="点击阅读《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="s3"><a class="chapter" href="<?php echo ($v['lastchapterurl']); ?>" title="<?php echo ($v['title']); echo ($v['lastchapter']); ?>阅读" target="_blank">更新到 <?php echo ($v['lastchapter']); ?></a></span>
						<span class="s4"><a><?php echo ($v["author"]); ?></a></span>
						<span class="s5"><?php echo ($v['updatetime']); ?></span>
					</li><?php endforeach; endif; ?>
				</ul>
			</div>
			<div class="r">
				<h2>
					最新入库小说
				</h2>
				<ul>
					<?php $k = '0'; ?>
					<?php if(is_array($newestlist)): foreach($newestlist as $key=>$v): $k = $k+1; ?>
					<li>
						<span class="num<?php echo ($k); ?> numer"><?php echo ($k); ?></span>
						<span class="s2"><a class="chaptea"  href="<?php echo ($v['rewriteurl']); ?>" title="最新收录小说《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="s5"><a class="numce"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></a></span>
						
					</li><?php endforeach; endif; ?>
				</ul>
			</div>
			<div class="clear">
			</div>
		</div>
<!-- 最新入库小说结束 -->
		<?php echo ($advcode["index_3"]["code"]); ?>
	</div>
	<div id="firendlink">
		友情连接：<?php if(is_array($TDK["flink"])): foreach($TDK["flink"] as $key=>$v3): ?><a href="<?php echo ($v3['url']); ?>" target="_blank"><?php echo ($v3['name']); ?></a><?php endforeach; endif; ?>
	</div>
	
<div class="footer">
	<div class="footer_link"></div>
	<div class="footer_cont">
		<script>footer();</script><?php echo ($statcode); ?>
	</div>
</div>
<?php if($comset["src"] != 'src'): ?><script src="//cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>
$(function() {
	$('[rel-class=lazyload]').lazyload({effect: "fadeIn"});
});
</script><?php endif; ?>
<?php echo ($advcode["global_footer"]["code"]); ?>

	
</div>
</body>
</html>